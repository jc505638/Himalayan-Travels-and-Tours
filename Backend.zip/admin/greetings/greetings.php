<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2 class="left">Welcome</h2>
						<div class="right">
							
						</div>
					</div>
					<!-- End Box Head -->	

					<!-- Table -->
					<div class="table">
						<p style="padding:20px;">Namaste,Welcome to our Himalayan Tour and Trek pages,that is a locally owned and managed trekking company established by a team of professionals who have long years of experience in travel, trekking, tour and adventure activities in Nepal and Tibet. We offer complete travel services to our clients including trekking, tours, peak climbing, expeditions, vehicle hiring, hotel booking, flight booking and many more sports activities in Himalayan country Nepal . As per the demand of our guests, we also organize various special interest tours like bird watching, golfing, spiritual tours, village tours, arrangements for yoga and meditation classes, offering various social activities programs. Since we specialize in adventure sports, we offer bungee jumping, paragliding, Ultralight flight, canoeing and mountain biking for sports lovers. Our travel programs are carefully designed after much research in the field. Our extensive relation with most hotels from deluxe to standard category, transport companies, flight carriers, government offices and tourism institutions make your vacation smooth, safe , and hassle free.</p><br/>
					</div>
					<!-- Table -->
					
				</div>
				
				</div>
				
				<!-- End Box -->
				