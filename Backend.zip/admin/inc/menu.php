<!-- Main Nav -->
		<div id="navigation">
			<ul>
			    <li><a href="index.php" class="active"><span>Home</span></a></li>
				<li><a href="index.php?folder=country&file=view.php"><span>Country</span></a></li>
				<li><a href="index.php?folder=travel_records&file=view.php"><span>Visit Records</span></a></li>
			</ul>
		</div>
		<!-- End Main Nav -->
        
        
  