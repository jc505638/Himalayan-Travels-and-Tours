<div id="top">
			<div id="top-navigation">
				
				<a href="logout.php">Sign out</a>
			</div>
		</div>