<?php
include('connect/connect.php');
include('user.php');
session_start();
if(isset($_POST['login']))
{
$user_name= $_POST['user_name'];
$password = $_POST['password'];

$result= $user->adminLogin($user_name, $password);
$num= $Conn->countNum($result);

if($num>0){
		$data = $Conn ->fetch($result);
		$_SESSION['admin_name']=$data['user_name'];
		$_SESSION['admin_password']=$data['password'];
		header('location:index.php');
	}
	else
	{
		echo "Error: Login Failed";
	}
	}
?>




<script type="text/javascript">
function abc(){
<?php
session_start();
if(isset($_SESSION['id'])){
	header('location:index.php');
}
if(isset($_GET['err'])){
	?>

alert('Login Fail!!!');
<?php
}
?>
}
</script>


<!DOCTYPE html>
<html>
<head>

<meta name="keywords" content="<?php echo $page_title;?>">
<meta name="description" content="<?php echo $details_description;?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
form {
    border: 3px solid 
    #f1f1f1;
    width: 30%;
    margin:auto;
}

input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 8%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
</head>
<body>

<form action="" method="post">
  <div class="imgcontainer">
    <img src="images/img_avatar2.png" alt="Avatar" class="avatar">
    <h4>Admin</h4>
  </div>

  <div class="container">
    <label for="user_name"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="user_name" required>

    <label for="password"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" required>
        
    <button type="submit" name="login" >Login</button>
    <label>
      <input type="checkbox" checked="checked" name="remember"> Remember me
    </label>
  </div>

  <div class="container" style="background-color:#f1f1f1">
    <button type="button" class="cancelbtn">Cancel</button>
    <span class="psw">Forgot <a href="#">password?</a></span>
  </div>
</form>

</body>
</html>

