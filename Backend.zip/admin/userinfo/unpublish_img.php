<?php
	if(!isset($_GET['id']))
	{
		header("Location: index.php?folder=userinfo&file=list_img.php&msg= Unpublish Success !!");
		
	}


	
	//get groups information in respect of Id
	$result = $UserInfo->getById($_GET['id']);
	$count = $Conn->numRows($result);
	if($count==0)
	{
		//$picture_id = $_GET['picture_id'];
		header("Location: index.php?folder=userinfo&file=list_img.php&msg= Unpublish Success !!");
	}
	else
	{
		$delete_result = $UserInfo->unpublish($_GET['id']);	
		if($delete_result==1)
		{
			//$picture_id = $_GET['picture_id'];
			header("Location: index.php?folder=userinfo&file=list_img.php&msg= Unpublish Success !!");
		}
		else
		{
			$wrong_msg = "<strong>Error:</strong><br/>".mysqli_error();
		}
	}
?>