<?php
class UserInfo
{
	//Add function
	public function add($fname,$lname,$address,$contact,$user_type,$email,
						$phone,$street,$country,$city,$username,$password,
						$user_id,$ext,$is_active){
		global $Conn;
		$fname =   $Conn->clean($fname);
		$lname =  $Conn->clean($lname);
		$address = $Conn->clean($address);
		$contact = $Conn->clean($contact);
		$user_type = $Conn->clean($user_type);
		$email = $Conn->clean($email);
		$phone =   $Conn->clean($phone);
		$street = $Conn->clean($street);
		$country = $Conn->clean($country);
		$city = $Conn->clean($city);
		$username = $Conn->clean($username);
		$password = md5($password);
		$password = $Conn->clean($password);
		$user_id = $Conn->clean($user_id);
		$ext = $Conn->clean($ext);
		$is_active = $Conn->clean($is_active);
		//prepare sql
		$sql = "INSERT INTO user_info(
								fname,lname,address,contact,user_type,email,phone,street,country,city,username,password,user_id,ext,is_active

								  ) 
								  VALUES
								  (
								  '$fname','$lname','$address','$contact','$user_type','$email','$phone','$street','$country','$city',
								  '$username','$password','$user_id','$ext','$is_active'
								  )";
		//execute query & store result
		$result=$Conn->execute($sql);
		//return result
		return $result;	
	}
	
	
	
	//Add function
	public function signUp($fname,$lname,$address,$contact,$user_type,$email,
						$phone,$street,$country,$city,$username,$password,
						$user_id,$ext,$is_active)
	{
		//refer connection link
		global $Conn;
		$fname =   $Conn->clean($fname);
		$lname =  $Conn->clean($lname);
		$address = $Conn->clean($address);
		$contact = $Conn->clean($contact);
		$user_type = $Conn->clean($user_type);
		$email = $Conn->clean($email);
		$phone =   $Conn->clean($phone);
		$street = $Conn->clean($street);
		$country = $Conn->clean($country);
		$city = $Conn->clean($city);
		$username = $Conn->clean($username);
		$password = md5($password);
		$password = $Conn->clean($password);
		$user_id = $Conn->clean($user_id);
		$ext = $Conn->clean($ext);
		$is_active = $Conn->clean($is_active);
		//prepare sql
		$sql = "INSERT INTO user_info(
								fname,lname,address,contact,user_type,email,phone,street,country,city,username,password,user_id,ext,is_active

								  ) 
								  VALUES
								  (
								  '$fname','$lname','$address','$contact','$user_type','$email','$phone','$street','$country','$city',
								  '$username','$password','$user_id','$ext','$is_active'
								  )";
		//execute query & store result
		$result=$Conn->execute($sql);
		//return result
		return $result;	
	}
	
	
	public function Req_bida($types_bida,$req_bida,$np_from,$np_to,$username,$is_active)
	{
		//refer connection link
		global $Conn;
		//clean function parameters
		
		$types_bida =  $Conn->clean($types_bida);
		$req_bida = $Conn->clean($req_bida);
		$np_from = $Conn->clean($np_from);
		$np_to = $Conn->clean($np_to);
		$username = $Conn->clean($username);
		$is_active = $Conn->clean($is_active);
		//prepare sql
		$sql = "INSERT INTO bida_calc(
								types_bida,req_bida,username,np_from,np_to,is_active
								  ) 
								  VALUES
								  (
								  '$types_bida','$req_bida','$username','$np_from','$np_to','$is_active'
								  )";
		//execute query & store result
		$result=$Conn->execute($sql);
		//return result
		return $result;	
	}
	
	
	//Update function
	public function update($id,$fname,$lname,$address,$contact,$user_type,$email,
						$phone,$street,$country,$city,$username,
						$user_id,$ext,$is_active)
	{
		global $Conn;
		$id=  $Conn->clean($id);
		$fname =   $Conn->clean($fname);
		$lname =  $Conn->clean($lname);
		$address = $Conn->clean($address);
		$contact = $Conn->clean($contact);
		$user_type = $Conn->clean($user_type);
		$email = $Conn->clean($email);
		$phone =   $Conn->clean($phone);
		$street = $Conn->clean($street);
		$country = $Conn->clean($country);
		$city = $Conn->clean($city);
		$username = $Conn->clean($username);
		$user_id = $Conn->clean($user_id);
		$ext = $Conn->clean($ext);
		$is_active = $Conn->clean($is_active);
		
		$sql = "UPDATE user_info SET
									fname='$fname',
									lname='$lname',
									address='$address',
									contact='$contact',
									user_type='$user_type',
									email = '$email',
									phone='$phone',
									street = '$street',
									country='$country',
									city = '$city',
									username = '$username',
									user_id = '$user_id',
									ext = '$ext',
									is_active = '$is_active'
								WHERE
									id=$id";	
		$result = $Conn->execute($sql);
		return $result;
	}
	
	
	public function update_c($fname,$lname,$address,$contact,$user_type,$email,
						$phone,$street,$country,$city,$username,
						$user_id,$ext,$is_active)
	{
		global $Conn;
			$fname =   $Conn->clean($fname);
		$lname =  $Conn->clean($lname);
		$address = $Conn->clean($address);
		$contact = $Conn->clean($contact);
		$user_type = $Conn->clean($user_type);
		$email = $Conn->clean($email);
		$phone =   $Conn->clean($phone);
		$street = $Conn->clean($street);
		$country = $Conn->clean($country);
		$city = $Conn->clean($city);
		$username = $Conn->clean($username);
		$user_id = $Conn->clean($user_id);
		$ext = $Conn->clean($ext);
		$is_active = $Conn->clean($is_active);
		$sql = "UPDATE user_info SET
									fname='$fname',
									lname='$lname',
									address='$address',
									contact='$contact',
									user_type='$user_type',
									email = '$email',
									phone='$phone',
									street = '$street',
									country='$country',
									city = '$city',
									user_id = '$user_id',
									ext = '$ext',
									is_active = '$is_active'
								WHERE
									username='$username'";	
		$result = $Conn->execute($sql);
		return $result;
	}
	
	public function changePass($password,$username)
	{
		global $Conn;
		$username = $Conn->clean($username);
		$password =   $Conn->clean($password);
		$password = md5($password);
		$sql = "UPDATE user_info SET
									password='$password'
								WHERE
									username='$username'";	
		$result = $Conn->execute($sql);
		return $result;
	}
	
	
	
	//Delete function
	public function delete($id)
	{
		global $Conn;
		$id=  $Conn->clean($id);
		
		$sql = "DELETE FROM user_info WHERE id=$id";
		$result = $Conn->execute($sql);
		return $result;	
	}
	
	public function delete_app($id)
	{
		global $Conn;
		$id=  $Conn->clean($id);
		
		$sql = "DELETE FROM user_info WHERE id=$id";
		$result = $Conn->execute($sql);
		return $result;	
	}
	
	//getById function
	public function GetEmailIdByEmail($email)
	{
		global $Conn;	
		$email=  $Conn->clean($email);
		$sql = "SELECT email FROM user_info WHERE email='$email'";
		$result = $Conn->execute($sql);
		$row = $Conn->fetchArray($result);
		return $row['email'];	
	}
	
	public function GetUsernaameByEmail($email)
	{
		global $Conn;	
		$email=  $Conn->clean($email);
		$sql = "SELECT username FROM user_info WHERE email='$email'";
		$result = $Conn->execute($sql);
		$row = $Conn->fetchArray($result);
		return $row['username'];	
	}
	
	//getById function
	public function getById($id)
	{
		global $Conn;	
	
		$id=  $Conn->clean($id);
	
		$sql = "SELECT * FROM user_info WHERE id=$id";
		$result = $Conn->execute($sql);
		return $result;	
	}
	
	
	//GetAll Value function
	public function getAll()
	{
		global $Conn;
		$sql = "SELECT * FROM user_info ORDER By id";
		$result = $Conn->execute($sql);
		return $result;	
	}
	
	public function getAllApprove()
	{
		global $Conn;
		$sql = "SELECT * FROM user_info ORDER By id";
		$result = $Conn->execute($sql);
		return $result;	
	}
	
	
	
	public function getByPictureId($picture_id)
	{
		global $Conn;	
		$picture_id=  $Conn->clean($picture_id);
		$sql = "SELECT * FROM user_info WHERE picture_id=$picture_id";
		$result = $Conn->execute($sql);
		return $result;	
	}
	
	public function getByUsername($username)
	{
		global $Conn;	
		$username=  $Conn->clean($username);
		$sql = "SELECT * FROM user_info WHERE username='$username'";
		$result = $Conn->execute($sql);
		return $result;	
	}
	
		public function getByUserID($user_id)
	{
		global $Conn;	
		$user_id=  $Conn->clean($user_id);
		$sql = "SELECT * FROM user_info WHERE user_id='$user_id'";
		$result = $Conn->execute($sql);
		return $result;	
	}
	
	
	public function getByUsernameCalc($username)
	{
		global $Conn;	
		$username=  $Conn->clean($username);
		$sql = "SELECT * FROM user_info WHERE username='$username' AND is_active='Y' ORDER BY req_date DESC ";
		$result = $Conn->execute($sql);
		return $result;	
	}
	
	
	public function LoginCheck($username,$password)
	{
		global $Conn;
		
			$username = $Conn->clean($username);
			$password = $Conn->clean($password);
			$password = md5($password);
			$sql="SELECT count(*) AS u_count 
					FROM user_info 
						WHERE 
							username='$username' 
						AND 
							password='$password'
						AND
							is_active='Y' 
						 ";
			$result = $Conn->execute($sql);
				$row = $Conn->fetchArray($result);
					$u_count = $row['u_count'];	
						return $u_count;
	}
	
	
	public function getByPictureIdWithLimit($picture_id,$limit)
	{
		global $Conn;
		$picture_id=  $Conn->clean($picture_id);
		$sql="SELECT * FROM user_info WHERE picture_id=$picture_id LIMIT $limit";
		$result=$Conn->execute($sql);
		return $result;
	}	
	
	
function checkExistence($id)
	{
		global $Conn;
		$sql="SELECT COUNT(*) As counter FROM user_info
		WHERE
			id=$id";
		$result=$Conn->execute($sql, $Conn);
		$row=$Conn->fetchArray($result);
		$counter=$row['counter'];
		return $counter;
	}
	
	
	function publish($id,$is_active)
	{
		global $Conn;
		$id=$Conn->clean($id);
		$is_active=$Conn->clean($is_active);
		
		$sql = "UPDATE user_info
							SET
								is_active =  'Y'
								WHERE
									id=$id";	
		$result=$Conn->execute($sql);
		return $result;
	}
	
	function publish_app($id,$is_active)
	{
		global $Conn;
		$id=$Conn->clean($id);
		$is_active=$Conn->clean($is_active);
		
		$sql = "UPDATE user_info
							SET
								is_active =  'Y'
								WHERE
									id=$id";	
		$result=$Conn->execute($sql);
		return $result;
	}
	
	function unpublish($id,$is_active)
	{
		global $Conn;
		$id=$Conn->clean($id);
		$is_active=$Conn->clean($is_active);
		
		$sql = "UPDATE user_info
							SET
								is_active =  'N'
								WHERE
									id=$id";	
		$result=$Conn->execute($sql);	
		return $result;
	}
	
	function unpublish_app($id,$is_active)
	{
		global $Conn;
		$id=$Conn->clean($id);
		$is_active=$Conn->clean($is_active);
		
		$sql = "UPDATE user_info
							SET
								is_active =  'N'
								WHERE
									id=$id";	
		$result=$Conn->execute($sql);	
		return $result;
	}
	
	
	
	
	
	
	 function addBida($name,$is_active)
	{
		global $Conn;
		$name =   $Conn->clean($name);
		$is_active =   $Conn->clean($is_active);
		$sql = "INSERT INTO user_info(
								name,is_active
								  ) 
								  VALUES
								  (
								  '$name','$is_active'
								  )";
		$result=$Conn->execute($sql);
		return $result;	
	}
	
	 function updateBida($id,$name,$is_active)
	{
		global $Conn;
		$id =   $Conn->clean($id);
		$name =   $Conn->clean($name);
		$is_active =   $Conn->clean($is_active);
		$sql ="UPDATE user_info SET
									name='$name',
									is_active='$is_active'
								WHERE
									id=$id";	
		$result=$Conn->execute($sql);
		return $result;	
	}
	

	function getAllBida()
	{
		global $Conn;
		$sql = "SELECT * FROM user_info ORDER By id DESC";
		$result = $Conn->execute($sql);
		return $result;	
	}
	
	function getNormalUser()
	{
		global $Conn;	
		$sql = "SELECT * FROM user_info WHERE user_type='normal'";
		$result = $Conn->execute($sql);
		return $result;	
	}
	function getEmpUser()
	{
		global $Conn;	
		$sql = "SELECT * FROM user_info WHERE user_type='emp'";
		$result = $Conn->execute($sql);
		return $result;	
	}
	
	function getActiveUser()
	{
		global $Conn;	
		$sql = "SELECT * FROM user_info WHERE is_active='y'";
		$result = $Conn->execute($sql);
		return $result;	
	}
	
	function getDactiveUser()
	{
		global $Conn;	
		$sql = "SELECT * FROM user_info WHERE is_active='N'";
		$result = $Conn->execute($sql);
		return $result;	
	}
	
	public function delete_Bida($id)
	{
		global $Conn;
		$id=  $Conn->clean($id);
		
		$sql = "DELETE FROM user_info WHERE id=$id";
		$result = $Conn->execute($sql);
		return $result;	
	}
	
	//getById function
	public function GetAllUser()
	{
		global $Conn;	
		$sql = "SELECT COUNT(*) FROM user_info";
		$result = $Conn->execute($sql);
		return $result;	
	}
	
	
	public function userReceived()
	{
		global $Conn;	
		$sql = "SELECT * FROM user WHERE received='0' LIMIT 20";
		$result = $Conn->execute($sql);
		return $result;	
	}
	
	
	function ActiveAccount($user_id,$is_active)
	{
		global $Conn;
		$user_id=$Conn->clean($user_id);
		$is_active=$Conn->clean($is_active);
		
		$sql = "UPDATE user_info
							SET
								is_active='$is_active'
								WHERE
									user_id='$user_id'";	
		$result=$Conn->execute($sql);
		return $result;
	}
	
	
	
	
}
$UserInfo = new UserInfo;
?>