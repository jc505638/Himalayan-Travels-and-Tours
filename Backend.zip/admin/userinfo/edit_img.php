<?php
 if(!isset($_GET['id']))
 {
	header("Location: index.php?folder=userinfo&file=list_img.php");
 }
	$result = $user_info->getById($_GET['id']);
		$count = $Conn->numRows($result);
		if($count==0)
		{
			header("Location: index.php?folder=userinfo&file=list_img.php");
		}
			$row = $Conn->fetchArray($result);
				$id=$row['id'];
				$fname=$row['fname'];
				$lname=$row['lname'];
				$address=$row['address'];
				$contact = $row['contact'];
				$user_type=$row['user_type'];
				$email = $row['email'];
				$phone=$row['phone'];
				$street = $row['street'];
				$country=$row['country'];
				$city = $row['city'];
				$username = $row['username'];
				$user_id = $row['user_id'];
				$is_active = $row['is_active'];
				$ext = $row['ext'];
				$file = USER_IMG_DIR.$row['id'].".".$row['ext'];
				
				
				?>

<div class="message_area">
<?php
if(isset($_POST['update_data']))
{
	if($_FILES['ext']['name'] != "")
	{
		$id = $_GET['id'];
		$fname=$_POST['fname'];
		$lname=$_POST['lname'];
		$address=$_POST['address'];
		$contact = "nodata";
		$user_type=$_POST['user_type'];
		$email = $_POST['email'];
		$phone="nodata";
		$street ="nodata";
		$country=$_POST['country'];
		$city = $_POST['city'];
		$username = $_POST['username'];
		$user_id = $_POST['user_id'];
		$is_active = $_POST['is_active'];
		
		$ext = pathinfo($_FILES['ext']['name'],PATHINFO_EXTENSION);
		$ext=strtolower($ext);
		
		$size=$_FILES['ext']['size'];// bytes// 1 MB = 1000000 bytes
			$allowed=array('jpg', 'jpeg', 'gif', 'png', 'bmw');
			if(!empty($ext))
			{
				if(!in_array($ext, $allowed))
				{
					$error_file_upload="Please upload Image in 'jpg', 'jpeg', 'gif', 'png', 'bmw' formats";		
				}
				else if($size>1000000)
				{
					$error_file_upload="File size should be less then 1mb";
				}
			}
			else
			{
				$error_file_upload=" No file Selection ";
			}  
			if(file_exists($file))
			{
				@unlink($file);
			}
              $new_file_name = $id.".".$ext;
       
			$result = $user_info-> update($id,$fname,$lname,$address,$contact,$user_type,$email,
						$phone,$street,$country,$city,$username,
						$user_id,$ext,$is_active);
			
			$new_id = $_GET['id'];
			$new_name = $new_id . "." . $ext;
			move_uploaded_file($_FILES['ext']['tmp_name'],USER_IMG_DIR.$new_name);
		
		if($result==1)
		{
			$id=$_GET['id'];
			header("Location: index.php?folder=userinfo&file=list_img.php&id=$id&msg=Update Success !!");
		}
		else
		{
			?>
			<div class="error_box">
				<?php echo "Error <br />".mysqli_error($Conn->link);?>
			</div>
        <?php
		}
	}else{
		
			$id = $Conn->clean($_GET['id']);
			$counter = $user_info->checkExistence($id);				
			$result = $user_info->getById($id);
			$row = $Conn->fetchArray($result);
		

			$id = $_GET['id'];
			$fname=$_POST['fname'];
			$lname=$_POST['lname'];
			$address=$_POST['address'];
			$contact = "nodata";
			$user_type=$_POST['user_type'];
			$email = $_POST['email'];
			$phone="nodata";
			$street = "nodata";
			$country=$_POST['country'];
			$city = $_POST['city'];
			$username = $_POST['username'];
			$user_id = $_POST['user_id'];
			$is_active = $_POST['is_active'];
			
			
			$new_id = $_GET['id'];
			$new_name = $row['id'].".".$row['ext'];
			
			$result = $user_info->update($id,$fname,$lname,$address,$contact,$user_type,$email,
						$phone,$street,$country,$city,$username,
						$user_id,$ext,$is_active);
			if($result==1)
		{
			$id=$_GET['id'];
			header("Location: index.php?folder=userinfo&file=list_img.php&id=$id&msg=Update Success !!");
		}
		else
		{
			?>
			<div class="error_box">
				<?php echo "Error <br />".mysqli_error($Conn->link);?>
			</div>
        <?php
		}
		
	}
}
?>
	
</div><!-- message_area ends -->

<div align="right">
		<h2 style="float:left; margin-left:5px; background:url(graphics/addnew/slider_icon.gif) no-repeat; text-indent:40px; Padding:5px;">User Management >> Edit</h2>
		 <a style="float:right; margin-right:5px;" href="index.php?folder=userinfo&file=list_img.php"><img src="graphics/addnew/go_back.gif" height="40" width="40" alt="Go Back" title="Click Here To Go Back"  /></a> 
		 <a style="float:right;  margin-right:10px;" href="index.php?folder=userinfo&file=add_img.php"><img src="graphics/addnew/add.png" height="40" width="40"  alt="Go Back" title="Click Here To Add New User"  /></a> 
	</div>

	<div class="clear"></div>
<div class="ram">
	<form method="post" enctype="multipart/form-data"  class="">
		
				
				<div class="form_item">
  					<div class="form_label">
    					<strong> First Name</strong>
    				</div>
    				<div class="form_field">
    					<input type="text" size="50" name="fname" value="<?php echo $fname; ?>" />
   		 			</div>
				</div>
				
				<div class="form_item">
  					<div class="form_label">
    					<strong> Last Name</strong>
    				</div>
    				<div class="form_field">
    					<input type="text" size="50" name="lname" value="<?php echo $lname; ?>" />
   		 			</div>
				</div>
				
				<div class="form_item">
  					<div class="form_label">
    					<strong> Address</strong>
    				</div>
    				<div class="form_field">
    					<input type="text" size="40" name="address" value="<?php echo $address; ?>" />
   		 			</div>
				</div>
				
				
				
				 <div class="form_item">
  					<div class="form_label">
    					<strong>User Type </strong>
    				</div>
    				<div class="form_field">
						<select name="user_type">
							<?php
								$values=array('admin', 'emp','normal');
								 foreach ($values as $v)
								 {
									if($user_type==$v)
									{
										echo "<option value='$v' selected>$v *</option>";
									}
									else 
									{
									echo "<option value='$v'>$v</option>";
									}
								 }
							 ?>
						</select>
						
   		 			</div>
			</div>
			
				
				<div class="form_item">
  					<div class="form_label">
    					<strong>Email</strong>
    				</div>
    				<div class="form_field">
						<input type="text" size="50" name="email" value="<?php echo $email; ?>" />
						
   		 			</div>
				</div>
				
			<div class="form_item">
  					<div class="form_label">
    					<strong>Country </strong>
    				</div>
    				<div class="form_field">
						<input type="text" size="40" name="country" value="<?php echo $country;?>" />
   		 			</div>
			</div>
			
			<div class="form_item">
  					<div class="form_label">
    					<strong>City </strong>
    				</div>
    				<div class="form_field">
						<input type="text" size="40" name="city"  value="<?php echo $city;?>" />
   		 			</div>
			</div>
			
			<div class="form_item">
  					<div class="form_label">
    					<strong>User Id </strong>
    				</div>
    				<div class="form_field">
						<input type="text" size="40" name="user_id"  value="<?php echo $user_id;?>" />
   		 			</div>
			</div>
				
				
				
				<div class="form_item">
  					<div class="form_label">
    					<strong>Photo</strong>
    				</div>
    				<div class="form_field">
						<input type="file" size="50" name="ext" />
					<?php	
						if(file_exists($file))
						{
					?>
					<img src="<?php echo $file;?>"  height="60" width="110"  />
					<?php
						}else{
						?>
						<img src="<?php echo NOPHOTO_IMG_DIR;?>"  height="60" width="110"  />
						
					<?php
						}
					?>
					
					
						
   		 			</div>
				</div>
				
						
				<div class="form_item">
  					<div class="form_label">
    					<strong>Is Active</strong>
    				</div>
    				<div class="form_field">
						<select name="is_active">
							<?php
								$values=array('Yes', 'No');
								 foreach ($values as $v)
								 {
									if($is_active==$v)
									{
										echo "<option value='$v' selected>$v *</option>";
									}
									else 
									{
									echo "<option value='$v'>$v</option>";
									}
								 }
							 ?>
						</select>
   		 			</div>
				</div>
				
				
				
				
				
				
				 <div class="form_item">
  					<div class="form_label">
    					<strong> Username </strong>
    				</div>
    				<div class="form_field">
						<input type="text" size="40" value="<?php echo $username;?>" name="username" />
   		 			</div>
			</div>
			
			
			
			
				
				<div class="form_item">
					<div class="form_strong">
    					<strong> </strong>
    				</div>
    				<div class="">
    					<input  class="submit_bitton" type="submit" title="Click Here To Save & Upadte " value="Save & Update" name="update_data" />
   		 			</div>
				</div>

		
	</form>
</div><!-- form_area ends-->
