<?php
	if(!isset($_GET['id']))
	{
		header("Location: index.php?folder=userinfo&file=list_img.php&msg= Publish Success !!");
		
	}


	
	//get groups information in respect of Id
	$result = $UserInfo->getById($_GET['id']);
	$count = $Conn->numRows($result);
	if($count==0)
	{
		
		header("Location: index.php?folder=userinfo&file=list_img.php&msg= Publish Success !!");
	}
	else
	{
		$delete_result = $UserInfo->publish($_GET['id']);	
		if($delete_result==1)
		{
		
			header("Location: index.php?folder=userinfo&file=list_img.php&msg= Publish Success !!");
		}
		else
		{
			$wrong_msg = "<strong>Error:</strong><br/>".mysqli_error();
		}
	}
?>