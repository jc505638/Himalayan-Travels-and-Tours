<?php
	class user1
	{
		public function adminLogin($user_name, $password)
		{
			global $Conn;
			
			$user_name = $Conn -> clean($user_name);
			$password = $Conn -> clean($password);
			
			$query = "select * from admin where user_name='$user_name' AND password='$password'";
			$result = $Conn-> run($query);
			return $result;
		}
		
		public function signup($user_name, $first_name, $last_name, $address , $dob, $sex, $contact_no, $email, $password)
		{
			global $Conn;
			
			$user_name = $Conn -> clean($user_name);
			$first_name = $Conn -> clean($first_name);
			$last_name = $Conn -> clean($last_name);
			$address = $Conn -> clean($address);
			$dob = $Conn -> clean($dob);
			$sex = $Conn -> clean($sex);
			$contact_no = $Conn -> clean($contact_no);
			$email = $Conn -> clean($email);
			$password = $Conn -> clean($password);
			
			$query= "INSERT INTO user(user_name, first_name, last_name, address , dob, sex, contact_no, email, password)
			VALUES('$user_name', '$first_name', '$last_name', '$address', '$dob', '$sex','$contact_no',  '$email', '$password' )";
			$result = $Conn-> run($query);
			return $result;
			
		}
		
		
		public function login($user_name, $password)
		{
			global $Conn;
			$user_name = $Conn -> clean($user_name);
			$password = $Conn -> clean($password);
			
			$query = "select * from user where user_name='$user_name' AND password='$password'";
			$result = $Conn-> run($query);
			return $result;
		}
		
		public function select()
		{
			global $Conn;
			
			$query= "select * from user";
			$result= $Conn -> run($query);
			return $result;
		}
		public function getId($id)
		{
			global $Conn;
			$query = "select * from user where id= $id";
			$result= $Conn-> run($query);
			return $result;
		}
		public function getById()
		{
			global $Conn;
			$query = "select * from user limit 1";
			$result= $Conn-> run($query);
			return $result;
		}
			//User Comments
	public function addComment($name,$email,$comment,$single_id)
	{
		//refer connection link
		global $Conn;
		$name =   $Conn->clean($name);
		$email =  $Conn->clean($email);
		$comment = $Conn->clean($comment);
		$single_id = $Conn->clean($single_id);
		
		//prepare sql
		$sql = "INSERT INTO comments(name,email,comment,single_id) 
								  VALUES
								  (
								  '$name','$email','$comment','$single_id')";
		
		$result=$Conn->run($sql);
		return $result;	
	}
	public function getCommentId($id)
		{
			global $Conn;
			$query = "select * from comments where single_id= $id";
			$result= $Conn-> run($query);
			return $result;
		}
	}
	
	$user = new user1();
?>