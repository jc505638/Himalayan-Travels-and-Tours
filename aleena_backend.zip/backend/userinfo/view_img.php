<?php
 if(!isset($_GET['id']))
 {
	header('Location: index.php?folder=userinfo&file=list_img.php');
 }
	
	//get feedback information in respect of Id
	$result = $UserInfo->getById($_GET['id']);
		$count = $Conn->numRows($result);
		if($count==0)
		{
			header('Location: index.php?folder=userinfo&file=list_img.php');
		}
			$row = $Conn->fetchArray($result);
				$fname=$row['fname'];
				$lname=$row['lname'];
				$address=$row['address'];
				$contact = $row['contact'];
				$user_type=$row['user_type'];
				$email = $row['email'];
				$phone=$row['phone'];
				$street = $row['street'];
				$country=$row['country'];
				$city = $row['city'];
				$username = $row['username'];
				$user_id = $row['user_id'];
				$is_active = $row['is_active'];
				$ext = $row['ext'];
				$file = USER_IMG_DIR.$row['id'].".".$row['ext'];
	?>

<div class="form_area">
  <div style="clear:both;"></div>
  
	<div align="right">
		<h2 style="float:left; margin-left:5px; background:url(graphics/addnew/slider_icon.gif) no-repeat; text-indent:40px; Padding:5px;">User Management >> View</h2>
		 <a style="float:right; margin-right:5px;" href="index.php?folder=userinfo&file=list_img.php"><img src="graphics/addnew/go_back.gif" height="40" width="40" alt="Go Back" title="Click Here To Go Back"  /></a> 
		 <a style="float:right;  margin-right:10px;" href="index.php?folder=userinfo&file=add_img.php"><img src="graphics/addnew/add.png" height="40" width="40"  alt="Go Back" title="Click Here To Add New Group"  /></a> 
	</div>

  
<div style="clear:both;"></div>	
	
	
<form method="post" class="niceform">
			
			
			<table style="float:left;background:none;"  width="30%">
			<tr>
					<?php
					

						
						if(file_exists($file))
						{
					?>
					<td width="40%"><img src="<?php echo $file ;?>" height="150" width="150"/></td>
					<?php
						}else{
						?>
						<td width="40%"><img src="<?php echo NOPHOTO_IMG_DIR;?>" height="150" width="150"/></td>
					<?php
						}
					?>
					<td></td>
				</tr>
				<tr>
					<td width="40%">Name</td>
					<td><?php echo $fname." ".$lname;?></td>
				</tr>
				
				<tr>
					<td width="40%">Address</td>
					<td><?php echo $address;?></td>
				</tr>
				
				
				<tr>
					<td width="40%">Contact</td>
					<td><?php echo $contact;?></td>
				</tr>
				
				<tr>
					<td width="40%">User Type</td>
					<td><?php echo $user_type;?></td>
				</tr>
				
				<tr>
					<td width="40%">Email</td>
					<td><?php echo $email;?></td>
				</tr>
				
				<tr>
					<td width="40%">Phone</td>
					<td><?php echo $phone;?></td>
				</tr>
				
				<tr>
					<td width="40%">Street</td>
					<td><?php echo $street;?></td>
				</tr>
				
				<tr>
					<td width="40%">Country</td>
					<td><?php echo $country;?></td>
				</tr>
				<tr>
					<td width="40%">City</td>
					<td><?php echo $city;?></td>
				</tr>
				
				<tr>
					<td width="40%">User id</td>
					<td><?php echo $user_id;?></td>
				</tr>
				
				<tr>
					<td width="40%">Username</td>
					<td><?php echo $username;?></td>
				</tr>
			
			</table>
		<table style="float:left;" width="60%" >
		
		somting else
			</table>
		<div class="clear"></div>
	<br>
	
		<div class="form_item">
  					
    				<div class="form_field">
						<a href="index.php?folder=userinfo&file=edit_img.php&id=<?php echo $_GET['id'];?>">Edit</a>
                           |  	<a href="index.php?folder=userinfo&file=delete_img.php&id=<?php echo $_GET['id'];?>">Delete</a>
   		 			</div>
			</div>	

</form>
</div><!-- form_area ends-->
