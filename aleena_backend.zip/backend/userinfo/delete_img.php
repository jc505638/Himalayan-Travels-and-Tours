<?php
	if(!isset($_GET['id']))
	{
		$id=$_GET['id'];
		header("Location: index.php?folder=userinfo&file=list_img.php");
	}

	//get image information in respect of Id
	$id = $_GET['id'];
	$result = $user_info->getById($_GET['id']);
	$count = $Conn->numRows($result);
	if($count==0)
	{
		header("Location: index.php?folder=userinfo&file=list_img.php");
	}
	else
	{
		$delete_result = $user_info->delete($_GET['id']);	
		if($delete_result==1)
		{
			$id=$_GET['id'];
			$row=$Conn->fetchArray($result);
			@unlink(USER_IMG_DIR.$row['id'].'.'.$row['ext']);
			
			header("Location: index.php?folder=userinfo&file=list_img.php&msg=Delete Success !!");
		}
		else
		{
			?>
            <div class="error_box">
				<?php $msg = "<strong>Error:</strong><br/>".mysqli_error();?>
            </div>
            <?php
			$id=$_GET['id'];
				header("Location: index.php?folder=userinfo&file=list_img.php");
		}
	}	
?>
