<div class="message_area">
<?php
//error_reporting(E_ALL);
if(isset($_POST['add_data']))
{		
	$fname=$_POST['fname'];
	$lname=$_POST['lname'];
	$address=$_POST['address'];
	$contact = "nodata";
	$user_type=$_POST['user_type'];
	$email = $_POST['email'];
	$phone="nodata";
	$street = "nodata";
	$country=$_POST['country'];
	$city = $_POST['city'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$user_id = $_POST['user_id'];
	$is_active = $_POST['is_active'];
	
		$ext = pathinfo($_FILES['ext']['name'],PATHINFO_EXTENSION);
		$ext=strtolower($ext);

		$result =  $user_info->add($fname,$lname,$address,$contact,$user_type,$email,
						$phone,$street,$country,$city,$username,$password,
						$user_id,$ext,$is_active);
		
		$new_id = $Conn->insertId();
		$new_name = $new_id . "." . $ext;

	if($result==1)
	{
		move_uploaded_file($_FILES['ext']['tmp_name'],USER_IMG_DIR.$new_name);
		header("Location: index.php?folder=userinfo&file=list_img.php&msg=Added Success !!");
	}
	else
	{
	?>
		<div class="error_box">
			<?php echo "Error <br />".mysqli_error();?>
		</div>
	<?php
	}
	
}
?>
</div>
  <div style="clear:both;"></div>
  
	<div align="right">
		<h2 style="float:left; margin-left:5px; background:url(graphics/addnew/slider_icon.gif) no-repeat; text-indent:40px; Padding:5px;">User Management >> Add New</h2>
		 <a style="float:right; margin-right:5px;" href="index.php"><img src="graphics/addnew/go_back.gif" height="40" width="40" alt="Go Back" title="Click Here To Go Back"  /></a> 
		 <a style="float:right;  margin-right:10px;" href="index.php?folder=img&file=add_img.php"><img src="graphics/addnew/add.png" height="40" width="40"  alt="Go Back" title="Click Here To Add New User"  /></a> 
	</div>

  
<div style="clear:both;"></div>	

<div class="form_area">
<form method="post" enctype="multipart/form-data" >
			
			
             <div class="form_item">
  					<div class="form_label">
    					<strong>  First Name </strong>
    				</div>
    				<div class="form_field">
    					<input type="text" size="40" name="fname" />
   		 			</div>
			</div>
			
			
             <div class="form_item">
  					<div class="form_label">
    					<strong>  Last Name </strong>
    				</div>
    				<div class="form_field">
    					<input type="text" size="40" name="lname" />
   		 			</div>
			</div>
			
			 <div class="form_item">
  					<div class="form_label">
    					<strong> Address </strong>
    				</div>
    				<div class="form_field">
    					<input type="text" size="40" name="address" />
   		 			</div>
			</div>
			
		
			
			 <div class="form_item">
  					<div class="form_label">
    					<strong>User Type </strong>
    				</div>
    				<div class="form_field">
						<select name="user_type">
							<option value="admin">Administrator</option>
							<option value="emp">Employee</option>
							<option value="normal">User</option>
						</select>
   		 			</div>
			</div>
			<div class="form_item">
  					<div class="form_label">
    					<strong> Email </strong>
    				</div>
    				<div class="form_field">
						<input type="email" size="40" name="email" />
   		 			</div>
			</div>
			
		
			
			
			<div class="form_item">
  					<div class="form_label">
    					<strong> Country  </strong>
    				</div>
    				<div class="form_field">
						<input type="text" size="40" name="country" />
   		 			</div>
			</div>
			
			<div class="form_item">
  					<div class="form_label">
    					<strong> City  </strong>
    				</div>
    				<div class="form_field">
						<input type="text" size="40" name="city" />
   		 			</div>
			</div>
			
			<div class="form_item">
  					<div class="form_label">
    					<strong> User Id  </strong>
    				</div>
    				<div class="form_field">
						<input type="text" size="40" name="user_id" />
   		 			</div>
			</div>
			
			
			 
			
			
			<div class="form_item">
  					<div class="form_label">
    					<strong> Photo </strong>
    				</div>
    				<div class="form_field">
						<input type="file" size="40" name="ext"/>
   		 			</div>
			</div>
			
			 

	</div>
	
	

			
			<div class="form_item">
  					<div class="form_label">
    					<strong>Is Active </strong>
    				</div>
    				<div class="form_field">
    					<select name="is_active">
							<option value="Y">Yes</option>
							<option value="N">No</option>
						</select>
   		 			</div>
			</div>
			
			
			
			
			
			 <div class="form_item">
  					<div class="form_label">
    					<strong> Username </strong>
    				</div>
    				<div class="form_field">
						<input type="text" size="40" name="username" />
   		 			</div>
			</div>
			
			<div class="form_item">
  					<div class="form_label">
    					<strong> Password </strong>
    				</div>
    				<div class="form_field">
						<input type="password" size="40" name="password" />
   		 			</div>
			</div>
			
			
			
			<div class="form_item">
    				<div class="">
    					<input class="submit_bitton" title="Click Here To Add New " type="submit" value="Add New User" name="add_data" />
   		 			</div>
			</div>

			
		
	</form>
</div>
